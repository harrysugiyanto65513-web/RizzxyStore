# Rizzxy Store

Proyek Android (Kotlin, tanpa library UI tambahan) + Shizuku.

## Build
- GitHub: upload semua isi folder ini, workflow `build.yml` (di `.github/workflows/`) otomatis jalan. APK ada di tab Actions > Artifacts.
- Android Studio (PC): Open folder ini, Build > Build APK(s). Perlu JDK 17.
- Tanpa Android Studio: install Gradle 8.7 + JDK 17 + Android SDK 34, lalu `gradle assembleDebug`.

## Pakai
1. Aktifkan Shizuku di HP/cloud phone, buka Rizzxy Store, beri izin.
2. Isi koordinat ketuk (kolom nama, Okay, Skip) sesuai layar game.
3. Pilih aplikasi, atur jeda, tekan MULAI.

Ganti nomor owner di `Prefs.kt` (`OWNER`).
