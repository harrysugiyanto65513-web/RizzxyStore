package com.rizzxy.store

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val BG = 0xFF0B1024.toInt()
    private val CARD = 0xFF141B38.toInt()
    private val TX = 0xFFE8ECFF.toInt()
    private val MU = 0xFF8E99C9.toInt()
    private val ACC = 0xFF35D6F5.toInt()
    private val INK = 0xFF06102A.toInt()
    private val FIELD = 0xFF0D1330.toInt()

    private lateinit var p: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var nav: LinearLayout
    private var tab = 0
    private val h = Handler(Looper.getMainLooper())
    private var statsTv: TextView? = null
    private var logTv: TextView? = null
    private var goBtn: TextView? = null
    private var shizukuTv: TextView? = null
    private val ticker = object : Runnable {
        override fun run() { refreshLive(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs.sp(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        scroll = ScrollView(this)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this).apply { setBackgroundColor(FIELD); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        listOf("Beranda", "Toko", "Hasil", "Akun").forEachIndexed { i, t ->
            val v = tv(t, 13f, MU).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { tab = i; render() }
            }
            nav.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        }
        render()
    }

    override fun onResume() { super.onResume(); h.post(ticker) }
    override fun onPause() { super.onPause(); h.removeCallbacks(ticker) }

    private fun render() {
        for (i in 0 until nav.childCount) {
            val v = nav.getChildAt(i) as TextView
            v.setTextColor(if (i == tab) ACC else MU)
            v.background = if (i == tab) round(0xFF16224D.toInt(), dp(12)) else null
        }
        statsTv = null; logTv = null; goBtn = null; shizukuTv = null
        scroll.removeAllViews()
        val page = when (tab) { 0 -> home(); 1 -> toko(); 2 -> hasil(); else -> akun() }
        page.addView(tv(Prefs.CREDIT, 12f, MU).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
        page.addView(tv("Owner: " + Prefs.OWNER, 12f, MU).apply { gravity = Gravity.CENTER })
        scroll.addView(page)
        refreshLive()
    }

    private fun refreshLive() {
        shizukuTv?.text = if (Shell.ready()) "Shizuku aktif" else if (Shell.running()) "Shizuku belum diizinkan (ketuk)" else "Shizuku belum jalan"
        statsTv?.text = "Dibuat ${Engine.made}   Dibuang ${Engine.dropped}   Relog ${Engine.relog}"
        logTv?.text = Engine.logText().ifEmpty { "Menunggu. Tekan MULAI." }
        goBtn?.text = if (Engine.running) "BERHENTI" else "MULAI"
    }

    // ---------- Halaman ----------
    private fun home(): LinearLayout {
        val page = pageBox()
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        head.addView(tv("Rizzxy Store", 22f, TX, true))
        shizukuTv = tv("", 13f, ACC).apply { setOnClickListener { Shell.ask() } }
        head.addView(shizukuTv)
        page.addView(head, lp())

        // Aplikasi
        val list = Prefs.pkgs(p)
        val sel = Prefs.sel(p)
        val countTv = tv("", 15f, TX, true)
        fun cnt() { countTv.text = "${list.count { sel.contains(it) }} aplikasi dipilih" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val toggle = btn("Ubah")
        fun fill() {
            box.removeAllViews()
            val bar = LinearLayout(this)
            val all = btn("Pilih semua").apply { setOnClickListener { sel.addAll(list); Prefs.saveSel(p, sel); fill(); cnt() } }
            val none = btn("Kosongkan").apply { setOnClickListener { sel.clear(); Prefs.saveSel(p, sel); fill(); cnt() } }
            bar.addView(all); bar.addView(none)
            box.addView(bar)
            list.forEachIndexed { i, pk ->
                box.addView(CheckBox(this).apply {
                    text = "${i + 1}. $pk"; setTextColor(TX); isChecked = sel.contains(pk)
                    setOnCheckedChangeListener { _, c ->
                        if (c) sel.add(pk) else sel.remove(pk)
                        Prefs.saveSel(p, sel); cnt()
                    }
                })
            }
            val add = EditText(this).apply { hint = "tambah paket, mis. com.zz46"; setHintTextColor(MU); setTextColor(TX); textSize = 13f }
            val addB = btn("Tambah").apply {
                setOnClickListener {
                    val t = add.text.toString().trim()
                    if (t.isNotEmpty() && !list.contains(t)) {
                        Prefs.savePkgs(p, list + t); sel.add(t); Prefs.saveSel(p, sel)
                        toast("Ditambah. Buka ulang halaman."); tab = 0; render()
                    }
                }
            }
            box.addView(add); box.addView(addB)
        }
        fill(); cnt()
        toggle.setOnClickListener {
            val open = box.visibility == View.GONE
            box.visibility = if (open) View.VISIBLE else View.GONE
            toggle.text = if (open) "Tutup" else "Ubah"
        }
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(countTv, LinearLayout.LayoutParams(0, -2, 1f)); topRow.addView(toggle)
        page.addView(card(
            sec("Aplikasi"), topRow, box,
            sw("Hilangkan pop-up izin notifikasi di semua cangkang", "popup", true),
            tv("Mode pembukaan cangkang", 12f, MU), seg("mode", listOf("Normal", "Dual Space"), 0),
            field("Maks. server per putaran (0 = tanpa batas; Dual Space tanpa batas)", "max", "40", true)
        ), lp())

        // Cara pindah
        val hint = tv("", 12f, MU)
        val hints = listOf(
            "Jalan sendiri sesuai jeda Step 1 dan Step 2.",
            "Pindah ke aplikasi berikutnya saat tombol LANJUT ditekan (belum ada di versi ini).",
            "Pindah saat layar game terlihat siap (belum ada di versi ini).",
            "Menunggu ZoneID terbaca baru pindah (belum ada di versi ini).")
        fun hintUp() { hint.text = hints[p.getInt("move", 0)] }
        hintUp()
        page.addView(card(
            sec("Cara pindah aplikasi"),
            seg("move", listOf("Otomatis", "Lanjut", "Lihat layar", "Tunggu ID"), 0) { hintUp() }, hint,
            twoCol(field("Jeda Step 1 (detik)", "d1", "6", true), field("Jeda Step 2 (detik)", "d2", "9", true))
        ), lp())

        // Step 2
        page.addView(card(
            sec("Urutan Step 2"),
            seg("order", listOf("Urut server", "Maju", "Terbalik"), 0),
            sw("Tutup cangkang yang sudah selesai Step 2", "closeDone", true),
            field("Nama karakter (4–20 karakter)", "nm", "carmen"),
            sw("Tambah nomor urut (nama01, nama02, ...)", "numbered", false),
            field("Mulai dari nomor", "start", "30", true),
            field("Nama activity (kosong = otomatis)", "activity", "")
        ), lp())

        page.addView(card(
            sec("Koordinat ketuk (piksel layar)"),
            tv("Isi sesuai layar HP/cloud phone kamu. Nol berarti dilewati.", 12f, MU),
            twoCol(field("Kolom nama X", "nameX", "0", true), field("Kolom nama Y", "nameY", "0", true)),
            twoCol(field("Tombol Okay X", "okX", "0", true), field("Tombol Okay Y", "okY", "0", true)),
            twoCol(field("Skip tutorial X", "skipX", "0", true), field("Skip tutorial Y", "skipY", "0", true))
        ), lp())

        val go = btn("MULAI").apply {
            textSize = 16f; gravity = Gravity.CENTER; setTextColor(INK)
            background = round(ACC, dp(14)); setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                if (Engine.running) { Engine.stop(); return@setOnClickListener }
                if (!Shell.ready()) { toast("Aktifkan Shizuku dan beri izin dulu"); Shell.ask(); return@setOnClickListener }
                startForegroundService(Intent(this@MainActivity, RunService::class.java))
            }
        }
        goBtn = go
        page.addView(go, lp())

        statsTv = tv("", 14f, TX, true)
        logTv = tv("", 11f, TX).apply { typeface = Typeface.MONOSPACE }
        page.addView(card(sec("Hasil terakhir"), statsTv!!, logTv!!), lp())
        return page
    }

    private fun toko(): LinearLayout {
        val page = pageBox()
        page.addView(card(sec("Toko"), tv("Belum ada produk.", 13f, MU)), lp())
        return page
    }

    private fun hasil(): LinearLayout {
        val page = pageBox()
        val c = card(sec("Hasil"))
        if (Engine.rows.isEmpty()) c.addView(tv("Belum ada hasil.", 13f, MU))
        Engine.rows.forEachIndexed { i, r ->
            c.addView(tv("${i + 1}. ${r.first}   ${if (r.second) "Hidup" else "Dibuang"}", 13f, if (r.second) 0xFF3BE08F.toInt() else 0xFFFF6B6B.toInt()))
        }
        page.addView(c, lp())
        return page
    }

    private fun akun(): LinearLayout {
        val page = pageBox()
        shizukuTv = tv("", 14f, ACC).apply { setOnClickListener { Shell.ask() } }
        page.addView(card(sec("Akun"), tv("Versi 1.0", 13f, MU), shizukuTv!!), lp())
        return page
    }

    // ---------- Pembantu tampilan ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
    private fun pageBox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(34), dp(14), dp(14)) }
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r.toFloat() }

    private fun tv(t: String, sz: Float = 14f, c: Int = TX, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun sec(t: String) = tv(t, 15f, TX, true).apply { setPadding(0, 0, 0, dp(6)) }

    private fun btn(t: String) = tv(t, 13f, TX).apply {
        background = round(FIELD, dp(10)); setPadding(dp(12), dp(8), dp(12), dp(8))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(4), dp(8), dp(4)) }
    }

    private fun card(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = round(CARD, dp(16))
        v.forEach { addView(it) }
    }

    private fun twoCol(a: View, b: View) = LinearLayout(this).apply {
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(8), 0) })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun sw(label: String, key: String, def: Boolean): LinearLayout {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        row.addView(tv(label, 14f, TX), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply {
            isChecked = p.getBoolean(key, def)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean(key, v).apply() }
        })
        return row
    }

    private fun field(label: String, key: String, def: String, num: Boolean = false): LinearLayout {
        val e = EditText(this).apply {
            setText(p.getString(key, def)); setTextColor(TX); textSize = 14f
            background = round(FIELD, dp(10)); setPadding(dp(10), dp(10), dp(10), dp(10))
            if (num) inputType = InputType.TYPE_CLASS_NUMBER
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { p.edit().putString(key, s.toString()).apply() }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(4))
            addView(tv(label, 12f, MU)); addView(e)
        }
    }

    private fun seg(key: String, opts: List<String>, def: Int, onChange: (() -> Unit)? = null): LinearLayout {
        val row = LinearLayout(this).apply { background = round(FIELD, dp(10)); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        val views = ArrayList<TextView>()
        fun paint() {
            val cur = p.getInt(key, def)
            views.forEachIndexed { i, v ->
                v.background = if (i == cur) round(ACC, dp(8)) else null
                v.setTextColor(if (i == cur) INK else MU)
            }
        }
        opts.forEachIndexed { i, o ->
            val v = tv(o, 13f, MU).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(9), 0, dp(9))
                setOnClickListener { p.edit().putInt(key, i).apply(); paint(); onChange?.invoke() }
            }
            views.add(v); row.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        }
        paint()
        return row
    }
}
