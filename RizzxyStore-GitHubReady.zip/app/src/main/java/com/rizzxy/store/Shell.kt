package com.rizzxy.store

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Shell {
    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun ask() { try { Shizuku.requestPermission(1001) } catch (e: Throwable) {} }

    // Menjalankan perintah shell lewat Shizuku (newProcess bersifat private, dipanggil lewat refleksi).
    fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val pr = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = pr.inputStream.bufferedReader().readText() + pr.errorStream.bufferedReader().readText()
        pr.waitFor()
        return out
    }
}
