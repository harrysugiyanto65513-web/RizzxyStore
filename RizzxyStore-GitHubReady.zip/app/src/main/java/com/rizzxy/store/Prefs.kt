package com.rizzxy.store

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    // Ganti dengan nomor owner kamu.
    const val OWNER = "isi nomor owner di sini"
    const val CREDIT = "Apk ini punya Rizzxy, jangan dijual belikan!!!"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("rizzxy", Context.MODE_PRIVATE)

    fun defaultPkgs(): List<String> {
        val l = ArrayList<String>()
        for (i in 0..9) l.add("com.zz$i")
        for (c in 'a'..'z') l.add("com.zz$c")
        for (c in 'a'..'i') l.add("com.zz1$c")
        return l.take(45)
    }

    fun pkgs(p: SharedPreferences): List<String> {
        val s = p.getString("pkgs", null) ?: return defaultPkgs()
        return s.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun savePkgs(p: SharedPreferences, l: List<String>) {
        p.edit().putString("pkgs", l.joinToString("\n")).apply()
    }

    fun sel(p: SharedPreferences): MutableSet<String> {
        val s = p.getStringSet("sel", null) ?: return pkgs(p).toMutableSet()
        return s.toMutableSet()
    }

    fun saveSel(p: SharedPreferences, s: Set<String>) {
        p.edit().putStringSet("sel", HashSet(s)).apply()
    }

    fun int(p: SharedPreferences, k: String, d: Int): Int = p.getString(k, null)?.trim()?.toIntOrNull() ?: d
}
