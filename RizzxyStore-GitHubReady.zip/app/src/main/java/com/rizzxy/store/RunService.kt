package com.rizzxy.store

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class RunService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("run", "Rizzxy Store", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "run")
            .setContentTitle("Rizzxy Store berjalan")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n)
        Engine.start(this) { stopSelf() }
        return START_NOT_STICKY
    }

    override fun onDestroy() { Engine.stop(); super.onDestroy() }
}
