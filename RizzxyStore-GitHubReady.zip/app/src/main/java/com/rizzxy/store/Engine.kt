package com.rizzxy.store

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

object Engine {
    @Volatile var running = false
    @Volatile var made = 0
    @Volatile var dropped = 0
    @Volatile var relog = 0
    @Volatile var current = ""
    val rows = CopyOnWriteArrayList<Pair<String, Boolean>>()
    private val log = StringBuilder()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun logText(): String = synchronized(log) { log.toString() }

    fun line(s: String) = synchronized(log) {
        log.append(fmt.format(Date())).append("  ").append(s).append('\n')
        if (log.length > 6000) log.delete(0, log.length - 5000)
    }

    fun start(ctx: Context, done: () -> Unit) {
        if (running) return
        running = true
        made = 0; dropped = 0; relog = 0; rows.clear()
        synchronized(log) { log.setLength(0) }
        Thread {
            try { run(ctx) } catch (e: Throwable) { line("Error: ${e.message}") }
            running = false
            current = ""
            line("Selesai.")
            done()
        }.start()
    }

    fun stop() { running = false }

    private fun waitSec(n: Int) {
        var i = 0
        while (running && i < n * 10) { Thread.sleep(100); i++ }
    }

    private fun launch(p: String, activity: String): Boolean {
        val out = if (activity.isBlank())
            Shell.exec("monkey -p $p -c android.intent.category.LAUNCHER 1")
        else Shell.exec("am start -n $p/$activity")
        return !(out.contains("No activities found") || out.contains("Error") || out.contains("not found"))
    }

    private fun tap(x: Int, y: Int) { if (x > 0 && y > 0) Shell.exec("input tap $x $y") }

    private fun run(ctx: Context) {
        val p = Prefs.sp(ctx)
        val dual = p.getInt("mode", 0) == 1
        val d1 = Prefs.int(p, "d1", 6)
        val d2 = Prefs.int(p, "d2", 9)
        val max = Prefs.int(p, "max", 40)
        val activity = p.getString("activity", "") ?: ""
        val sel = Prefs.sel(p)
        var list = Prefs.pkgs(p).filter { sel.contains(it) }
        if (!dual && max > 0) list = list.take(max)
        if (list.isEmpty()) { line("Tidak ada aplikasi dipilih."); return }
        line("Mulai: ${list.size} aplikasi, mode ${if (dual) "Dual Space" else "Normal"}")

        // Step 1: buka tiap aplikasi sampai game siap.
        for (pk in list) {
            if (!running) return
            current = "$pk · Step 1"
            val ok = launch(pk, activity)
            line("Step 1 · $pk · ${if (ok) "dibuka" else "gagal dibuka"}")
            if (!ok) { dropped++; rows.add(pk to false); continue }
            waitSec(d1)
        }

        // Step 2: buat karakter di tiap aplikasi (koordinat diatur di pengaturan).
        val order = if (p.getInt("order", 0) == 2) list.reversed() else list
        val base = (p.getString("nm", "carmen") ?: "carmen").trim()
        val numbered = p.getBoolean("numbered", false)
        var n = Prefs.int(p, "start", 1)
        val nx = Prefs.int(p, "nameX", 0); val ny = Prefs.int(p, "nameY", 0)
        val ox = Prefs.int(p, "okX", 0); val oy = Prefs.int(p, "okY", 0)
        val sx = Prefs.int(p, "skipX", 0); val sy = Prefs.int(p, "skipY", 0)
        val closeDone = p.getBoolean("closeDone", true)
        for (pk in order) {
            if (!running) return
            if (rows.any { it.first == pk && !it.second }) continue
            current = "$pk · Step 2"
            launch(pk, activity)
            waitSec(d2)
            if (nx > 0 && ny > 0) {
                var name = if (numbered) base + String.format("%02d", n) else base
                name = name.take(20)
                tap(nx, ny)
                repeat(25) { Shell.exec("input keyevent 67") }
                Shell.exec("input text '${name.replace("'", "")}'")
                tap(ox, oy); waitSec(2); tap(sx, sy)
                line("Step 2 · $pk · nama $name")
            } else {
                line("Step 2 · $pk · koordinat nama belum diatur, dilewati")
            }
            n++
            made++
            rows.add(pk to true)
            if (closeDone) Shell.exec("am force-stop $pk")
        }
    }
}
